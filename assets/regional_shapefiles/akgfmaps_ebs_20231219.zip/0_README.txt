Dataset name: Shapefiles for the NOAA/AFSC eastern and northern Bering Sea continental shelf summer bottom trawl surveys
Created by: NOAA Fisheries Alaska Fisheries Science Center, Resource Assessment and Conservation Engineering Division, Groundfish Assessment Program
Description: Created on 2023-12-19 using akgfmaps version 3.4.1
Website: https://github.com/afsc-gap-products/akgfmaps
Coordinate Reference System: WGS84
