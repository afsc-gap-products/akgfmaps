Dataset name: Shapefiles for the NOAA/AFSC northern Bering Sea shelf summer bottom trawl survey
Created by: NOAA Fisheries Alaska Fisheries Science Center, Resource Assessment and Conservation Engineering Division, Groundfish Assessment Program
Description: Created on 2024-05-20 using akgfmaps version 3.5.2
Website: https://github.com/afsc-gap-products/akgfmaps
Coordinate Reference System: EPSG:4269
