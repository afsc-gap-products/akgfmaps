Dataset name: Geopackage for NOAA/AFSC northern Bering Sea shelf summer bottom trawl survey
Created by: NOAA Fisheries Alaska Fisheries Science Center, Resource Assessment and Conservation Engineering Division, Groundfish Assessment Program
Description: Created on 2025-08-28 using akgfmaps version 4.1.2
Website: https://github.com/afsc-gap-products/akgfmaps
Coordinate Reference System: EPSG:3338
