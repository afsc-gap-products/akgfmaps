Dataset name: Geopackage for NOAA/AFSC Aleutian Islands summer bottom trawl survey
Created by: NOAA Fisheries Alaska Fisheries Science Center, Resource Assessment and Conservation Engineering Division, Groundfish Assessment Program
Description: Created on 2025-07-30 using akgfmaps version 4.0.8
Website: https://github.com/afsc-gap-products/akgfmaps
Coordinate Reference System: EPSG:3338
