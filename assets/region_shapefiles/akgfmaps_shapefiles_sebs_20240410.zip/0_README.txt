Dataset name: Shapefiles for the NOAA/AFSC eastern Bering Sea continental shelf summer bottom trawl survey
Created by: NOAA Fisheries Alaska Fisheries Science Center, Resource Assessment and Conservation Engineering Division, Groundfish Assessment Program
Description: Created on 2024-04-10 using akgfmaps version 3.5.1
Website: https://github.com/afsc-gap-products/akgfmaps
Coordinate Reference System: EPSG:4326
