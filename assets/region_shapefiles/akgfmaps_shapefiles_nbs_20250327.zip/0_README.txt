Dataset name: Geopackage for NOAA/AFSC northern Bering Sea shelf summer bottom trawl survey
Created by: NOAA Fisheries Alaska Fisheries Science Center, Resource Assessment and Conservation Engineering Division, Groundfish Assessment Program
Description: Created on 2025-03-27 using akgfmaps version 4.0.4
Website: https://github.com/afsc-gap-products/akgfmaps
Coordinate Reference System: EPSG:3338
